// src/pages/NotFound.jsx
import React from 'react';

function NotFound() {
    return <h2>Página não encontrada</h2>;
}

export default NotFound;
